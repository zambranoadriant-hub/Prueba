package com.tvmasterpro.matrix

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val green = Color.rgb(57, 255, 20)
    private val bg = Color.rgb(2, 8, 3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 34, 22, 28)
        }

        val title = TextView(this).apply {
            text = "TV MASTER PRO"
            textSize = 30f
            setTextColor(green)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        layout.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "MATRIX EDITION  •  ANDROID ZTE"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        layout.addView(subtitle, matchWrap())

        addInfo(layout, "Panel de configuración asistida", "Abre ajustes oficiales de Android. Tú decides qué cambiar; la aplicación no modifica el sistema por su cuenta.")
        addButton(layout, "WI-FI / RED", Settings.ACTION_WIFI_SETTINGS)
        addButton(layout, "PANTALLA", Settings.ACTION_DISPLAY_SETTINGS)
        addButton(layout, "SONIDO", Settings.ACTION_SOUND_SETTINGS)
        addButton(layout, "PRIVACIDAD", Settings.ACTION_PRIVACY_SETTINGS)
        addButton(layout, "AJUSTES GENERALES", Settings.ACTION_SETTINGS)

        addInfo(layout, "DNS privado y anuncios", "En Ajustes, busca “DNS privado” si tu versión de Android lo ofrece. Un DNS filtrante puede reducir algunos anuncios, pero no todos; algunas apps o redes pueden dejar de funcionar. No uses servidores desconocidos.")
        addInfo(layout, "Importante", "Esta app no puede eliminar anuncios dentro de todas las aplicaciones, acelerar físicamente el teléfono ni cambiar opciones protegidas automáticamente. No necesita permisos especiales ni recopila datos.")
        val footer = TextView(this).apply {
            text = "TV MASTER PRO MATRIX  •  Versión 1.0"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 4)
        }
        layout.addView(footer, matchWrap())

        scroll.addView(layout)
        setContentView(scroll)
    }

    private fun addInfo(parent: LinearLayout, heading: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.rgb(6, 23, 9))
        }
        val h = TextView(this).apply {
            text = heading
            textSize = 17f
            setTextColor(green)
            setTypeface(null, Typeface.BOLD)
        }
        val b = TextView(this).apply {
            text = body
            textSize = 14f
            setTextColor(Color.rgb(210, 235, 207))
            setPadding(0, 7, 0, 0)
        }
        box.addView(h, matchWrap())
        box.addView(b, matchWrap())
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = 14
        parent.addView(box, params)
    }

    private fun addButton(parent: LinearLayout, label: String, action: String) {
        val button = Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(green)
            setBackgroundColor(Color.rgb(13, 45, 17))
            isAllCaps = false
            setOnClickListener {
                try {
                    startActivity(Intent(action))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Este ajuste no está disponible en esta versión.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = 10
        parent.addView(button, params)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
