TV MASTER PRO MATRIX - PROYECTO ANDROID

Este ZIP contiene el PROYECTO FUENTE de una app Android, no un APK ya compilado.

Qué hace:
- Muestra un panel Matrix verde.
- Abre los ajustes oficiales de Wi-Fi, pantalla, sonido, privacidad y ajustes generales.
- Incluye orientación sobre DNS privado y publicidad.

Qué NO hace:
- No elimina todos los anuncios.
- No cambia ajustes protegidos sin autorización.
- No limpia RAM ni aumenta físicamente la velocidad.
- No recopila datos ni solicita permisos especiales.

Cómo generar el APK:
1. En un computador, instala Android Studio.
2. Abre la carpeta TV_MASTER_PRO_MATRIX_ANDROID.
3. Espera a que Gradle sincronice el proyecto.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio generará el APK en app/build/outputs/apk/debug/.

Compatibilidad prevista: Android 6.0 o posterior. La disponibilidad de cada acceso directo depende de la versión y personalización Android del ZTE.
